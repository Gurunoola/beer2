var path = require("path");

require(path.resolve(__dirname, 'preload.js'))
