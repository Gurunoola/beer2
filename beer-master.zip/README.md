# whatsapp-desktop-app

WhatsApp Web as a desktop application. 
Build using electron and NodeJS. 


Clone the repo:

    git clone https://github.com/niinpatel/whatsapp-desktop-app

Enter project directory -

    cd whatsapp-desktop-app

Install required packages -

    npm install 

Start the app -

    npm start 
