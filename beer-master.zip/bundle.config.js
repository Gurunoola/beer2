module.exports = {
  bundle: {
    main: {
      scripts: [
        'jquery-3.3.1.min.js',
        'preload.js'
      ]
    }
  }
};